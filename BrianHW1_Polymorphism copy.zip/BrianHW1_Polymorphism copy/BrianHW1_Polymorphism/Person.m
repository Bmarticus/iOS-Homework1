//
//  Person.m
//  BrianHW1_Polymorphism
//
//  Created by Brian Martinez on 9/26/17.
//  Copyright © 2017 Brian Martinez. All rights reserved.
//

#import "Person.h"

@implementation Person

//Get gender
-(NSString *)getGender {
    return @"NEUTRAL";
}

//Get name
-(NSString *)getName {
    return @"NEUTRAL";
}
@end
