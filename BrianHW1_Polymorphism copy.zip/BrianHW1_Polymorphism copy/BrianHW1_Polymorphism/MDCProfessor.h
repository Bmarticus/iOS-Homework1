//
//  MDCProfessor.h
//  BrianHW1_Polymorphism
//
//  Created by Brian Martinez on 9/26/17.
//  Copyright © 2017 Brian Martinez. All rights reserved.
//

#import "MDCPerson.h"

@interface MDCProfessor : MDCPerson

@end
