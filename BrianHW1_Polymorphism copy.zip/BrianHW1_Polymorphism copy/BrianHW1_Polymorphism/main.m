//
//  main.m
//  BrianHW1_Polymorphism
//
//  Created by Brian Martinez on 9/26/17.
//  Copyright © 2017 Brian Martinez. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "MDCPerson.h"
#import "MDCProfessor.h"
#import "MDCStudent.h"


int main(int argc, const char * argv[]) {
    @autoreleasepool {
        //create array for objects
        NSMutableArray *arrayPersons = [[NSMutableArray alloc]init];
        
        
        
        
    }
    return 0;
}
